<footer class="footer" height="10%">
   Copywrite &copy; by CODEFEST 2021
</footer>