
<header class="header">
    <div><h2>CODEFEST:2021</h2></div>
    <div>  
        <ul class="menu">
            <a href="index.php"><li>Home</li></a>
            <a href="AdvancedSearch.php"><li>Search</li></a>
            <li>About Us</li>
            <li>Contact Us</li> 
        </ul>

       </div>
    <div>Login Register</div>
</header><hr>
  <?php
            if(isset($_GET['msg'])){
                ?>
            <p  style="color: red;" align="center"><?php echo $_GET['msg'];?></p>
            <hr>
            <?php
} 
            ?>