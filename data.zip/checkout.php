<?php
session_start();
include './actions/dbConnection.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
          <link href="css/codefest_css.css" type="text/css" rel="stylesheet"/> 
    </head>
    <body>
        <?php include './include/header.php';?>
        <div align="center"> 
            <h2>Checkout</h2> 
            <table border="1"> 
                <b>Billing and Delivery Details</b>
                <form method="post" action="actions/checkoutAction.php" >
                <table border="0">
                        <tr>
                            <td>Name:</td>
                            <td><input type="text" name="name"></td>
                        </tr>
                        <tr>
                            <td>address:</td>
                            <td><textarea type="text" name="address"></textarea></td>
                        </tr>
                        <tr>
                            <td>City:</td>
                            <td><input type="text" name="city"></td>
                        </tr>
                        <tr>
                            <td>Contact Number:</td>
                            <td><input type="text" name="contactNumber"></td>
                        </tr>
                        <tr>
                            <td>Email:</td>
                            <td><input type="text" name="email"></td>
                        </tr>
                        <tr>
                            <td>Username:</td>
                            <td><input type="text" name="username"></td>
                        </tr>
                        <tr>
                            <td>Password:</td>
                            <td><input type="password" name="password"></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td><input type="submit" value="Update Billing Details"></td>
                        </tr>
                </table> 
                </form>
               
        </div>
        <?php include './include/footer.php';?>
        </body>
</html>
