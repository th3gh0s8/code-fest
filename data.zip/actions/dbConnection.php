<?php
$username = "root";
$password ="";
$database = "codefest";
$host = "localhost";
$port = "3306";

$conn = new mysqli($host, $username, $password, $database, $port);

if($conn->errno){
    echo "Error:".$conn->connect_error;
}else{
//    echo 'success';
}